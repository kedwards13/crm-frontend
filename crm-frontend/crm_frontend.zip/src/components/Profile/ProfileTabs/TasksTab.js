import React from 'react';

const TasksTab = () => (
  <div className="placeholder-tab">
    Assign follow-ups, show due dates, and auto-track.
  </div>
);

export default TasksTab;