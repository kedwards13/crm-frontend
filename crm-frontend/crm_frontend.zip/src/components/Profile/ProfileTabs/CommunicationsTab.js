import React from 'react';

const CommunicationsTab = () => (
  <div className="placeholder-tab">
    📞 Call + 💬 Text views coming. Logged via Twilio integration.
  </div>
);

export default CommunicationsTab;