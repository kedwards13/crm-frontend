import React from 'react';

const DocumentsTab = () => (
  <div className="placeholder-tab">
    Upload, preview, and track seller documents here.
  </div>
);

export default DocumentsTab;