import React from 'react';

const CustomerCare = () => {
  return (
    <div className="care-container">
      <h2>Customer Care</h2>
      <p>Respond to inquiries, manage reviews, follow-up, etc.</p>
    </div>
  );
};

export default CustomerCare;