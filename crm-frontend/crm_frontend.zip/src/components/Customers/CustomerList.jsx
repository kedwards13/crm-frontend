import React, { useState, useEffect, useRef } from "react";
import { getCustomers, enrichBulk, getCustomerMetrics, assignToCampaign } from "../../api/customersApi";
import CustomerCard from "../Profile/CustomerPopup";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Brain, Eye, Zap } from "lucide-react";

// ────────────────────────────────────────────────
// 💠 CustomerList — CRM Table + AI Enrichment Control
// ────────────────────────────────────────────────
export default function CustomerList() {
  const [search, setSearch] = useState(localStorage.getItem("customerSearch") || "");
  const [customers, setCustomers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [checked, setChecked] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [enriching, setEnriching] = useState(false);
  const [campaignId, setCampaignId] = useState("");
  const [error, setError] = useState("");

  const debounceRef = useRef(null);

  // ────────────────────────────────────────────────
  // 📡 Fetch customers with debounce
  // ────────────────────────────────────────────────
  const fetchCustomers = async () => {
    setLoading(true);
    setError("");
    try {
      const { data } = await getCustomers(search ? { q: search } : {});
      setCustomers(data.results || data);
    } catch (err) {
      console.error("❌ Error fetching customers:", err);
      setError("Failed to load customers.");
      setCustomers([]);
    } finally {
      setLoading(false);
    }
  };

  // ────────────────────────────────────────────────
  // 📊 Fetch tenant-level metrics
  // ────────────────────────────────────────────────
  const fetchMetrics = async () => {
    try {
      const { data } = await getCustomerMetrics();
      setMetrics(data);
    } catch (err) {
      console.warn("⚠️ Metrics unavailable:", err);
    }
  };

  // ────────────────────────────────────────────────
  // 🔁 Auto-refresh + Smart Search Memory
  // ────────────────────────────────────────────────
  useEffect(() => {
    localStorage.setItem("customerSearch", search);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(fetchCustomers, 400);
    return () => clearTimeout(debounceRef.current);
  }, [search]);

  useEffect(() => {
    fetchCustomers();
    fetchMetrics();
  }, []);

  // ────────────────────────────────────────────────
  // 🧠 Enrichment + Campaign Controls
  // ────────────────────────────────────────────────
  const toggleCheck = (id) => {
    setChecked((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const toggleSelectAll = () => {
    if (checked.length === customers.length) {
      setChecked([]);
    } else {
      setChecked(customers.map((c) => c.customer_id));
    }
  };

  const handleBulkEnrich = async () => {
    if (!checked.length) return toast.info("Select at least one customer first.");
    if (!window.confirm("Run AI enrichment on selected customers?")) return;
    setEnriching(true);
    try {
      await enrichBulk(checked);
      toast.success("AI enrichment started successfully!");
      fetchCustomers();
      fetchMetrics();
    } catch (err) {
      console.error("❌ Enrichment failed:", err);
      toast.error("AI enrichment failed. Check logs for details.");
    } finally {
      setEnriching(false);
    }
  };

  const handleAssignCampaign = async () => {
    if (!checked.length) return toast.info("Select customers to assign first.");
    if (!campaignId) return toast.warning("Please select a campaign first.");
    try {
      await assignToCampaign(campaignId, checked);
      toast.success(`Assigned ${checked.length} customers to campaign.`);
      setChecked([]);
    } catch (err) {
      console.error(err);
      toast.error("Campaign assignment failed.");
    }
  };

  // ────────────────────────────────────────────────
  // 🧱 Render
  // ────────────────────────────────────────────────
  return (
    <div className="p-4">
      {/* 🔍 Top bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between mb-5 gap-3">
        <input
          type="text"
          placeholder="Search customers..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-gray-300 rounded-lg p-2 w-full sm:w-1/2 focus:ring-2 focus:ring-blue-500 transition"
        />
        <div className="flex items-center gap-3">
          <select
            value={campaignId}
            onChange={(e) => setCampaignId(e.target.value)}
            className="border border-gray-300 rounded-lg p-2"
          >
            <option value="">Assign to campaign...</option>
            <option value="1">Welcome Series</option>
            <option value="2">Follow-Up</option>
            <option value="3">Reactivation</option>
          </select>
          <button
            onClick={handleAssignCampaign}
            disabled={!checked.length}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded font-medium"
          >
            Assign
          </button>
          <button
            onClick={handleBulkEnrich}
            disabled={!checked.length || enriching}
            className={`px-5 py-2 rounded text-white font-medium transition ${
              enriching ? "bg-emerald-400 cursor-not-allowed" : "bg-emerald-600 hover:bg-emerald-700"
            }`}
          >
            {enriching ? "Enriching..." : "AI Enrich"}
          </button>
        </div>
      </div>

      {/* 📈 Metrics summary */}
      {metrics && (
        <div className="bg-gray-50 border rounded-lg p-3 mb-5 text-sm flex flex-wrap gap-5 justify-between">
          <div>Customers: <b>{metrics.total_customers}</b></div>
          <div>Active: <b>{metrics.active_customers}</b></div>
          <div>Enriched: <b>{metrics.enriched_customers}</b></div>
          <div>No-Show Rate: <b>{metrics.no_show_rate}%</b></div>
          <div>Avg Visits: <b>{metrics.average_visits_per_customer}</b></div>
        </div>
      )}

      {/* ⚙️ Table Section */}
      {error && <div className="text-red-600 mb-3">{error}</div>}
      {loading ? (
        <div className="text-gray-500 animate-pulse">Loading customers...</div>
      ) : !customers.length ? (
        <div className="text-gray-600 italic">No customers found.</div>
      ) : (
        <div className="overflow-x-auto shadow border border-gray-200 rounded-lg">
          <table className="min-w-full text-sm bg-white">
            <thead className="bg-gray-100 text-gray-700 uppercase text-xs">
              <tr>
                <th className="p-2 text-center">
                  <input
                    type="checkbox"
                    checked={checked.length === customers.length}
                    onChange={toggleSelectAll}
                  />
                </th>
                <th className="p-2 text-left">Name</th>
                <th className="p-2 text-left">Email</th>
                <th className="p-2 text-left">Phone</th>
                <th className="p-2 text-left">City</th>
                <th className="p-2 text-left">State</th>
                <th className="p-2 text-left w-[200px]">AI Summary</th>
                <th className="p-2 text-center">AI Enriched</th>
                <th className="p-2 text-center">⚡ Actions</th>
              </tr>
            </thead>

            <tbody>
              {customers.map((c, i) => (
                <tr
                  key={c.customer_id || i}
                  onClick={() => setSelected(c)}
                  className="hover:bg-blue-50 cursor-pointer transition"
                >
                  <td className="text-center">
                    <input
                      type="checkbox"
                      checked={checked.includes(c.customer_id)}
                      onClick={(e) => e.stopPropagation()}
                      onChange={() => toggleCheck(c.customer_id)}
                    />
                  </td>
                  <td className="p-2 font-medium text-gray-900">{c.first_name} {c.last_name}</td>
                  <td className="p-2 text-gray-700">{c.primary_email || "—"}</td>
                  <td className="p-2 text-gray-700">{c.primary_phone || "—"}</td>
                  <td className="p-2 text-gray-600">{c.city || "—"}</td>
                  <td className="p-2 text-gray-600">{c.state || "—"}</td>
                  <td className="p-2 text-gray-500 truncate">{c.ai_summary?.slice(0, 120) || "—"}</td>
                  <td className="p-2 text-center">
                    {c.is_enriched ? (
                      <span className="text-emerald-600 font-semibold">✓</span>
                    ) : (
                      <span className="text-gray-400">—</span>
                    )}
                  </td>
                  <td className="p-2 text-center">
                    <div className="flex justify-center gap-2">
                      <button
                        title="Open Profile"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelected(c);
                        }}
                        className="p-1 rounded hover:bg-gray-100"
                      >
                        <Eye size={16} className="text-blue-500" />
                      </button>
                      <button
                        title="Run AI Enrich"
                        onClick={(e) => {
                          e.stopPropagation();
                          toast.info(`Running enrichment for ${c.first_name}...`);
                          enrichBulk([c.customer_id]);
                        }}
                        className="p-1 rounded hover:bg-gray-100"
                      >
                        <Brain size={16} className="text-emerald-600" />
                      </button>
                      <button
                        title="View AI Summary"
                        onClick={(e) => {
                          e.stopPropagation();
                          toast.info(c.ai_summary ? c.ai_summary : "No AI summary available.");
                        }}
                        className="p-1 rounded hover:bg-gray-100"
                      >
                        <Zap size={16} className="text-amber-500" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 🪟 Popup modal for full profile */}
      {selected && (
        <CustomerCard
          customer={selected}
          onClose={() => setSelected(null)}
          refresh={fetchCustomers}
        />
      )}
    </div>
  );
}