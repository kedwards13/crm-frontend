import React from "react";
import "./Inventory.css";
export default function CompliancePage(){
  return (
    <div className="inventory-page">
      <header className="inventory-head"><h1>Inventory Compliance</h1></header>
      <section className="inventory-card">Chemicals, SDS, expiries (stub).</section>
    </div>
  );
}