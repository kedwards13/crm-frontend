import React from "react";
import "./Inventory.css";
export default function VendorsPage(){
  return (
    <div className="inventory-page">
      <header className="inventory-head"><h1>Vendors</h1></header>
      <section className="inventory-card">Vendor directory & terms (stub).</section>
    </div>
  );
}