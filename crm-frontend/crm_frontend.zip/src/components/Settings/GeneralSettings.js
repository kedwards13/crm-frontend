import React from 'react';

const GeneralSettings = () => {
  return (
    <div>
      <h1>General Settings</h1>
      <p>Manage profile, preferences, and integrations here.</p>
    </div>
  );
};

export default GeneralSettings;